package filme.tipos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilmeApplicationTests {

	@Test
	void contextLoads() {
	}

}
